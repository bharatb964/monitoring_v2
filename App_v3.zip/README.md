
#### Real Time Monitoring Dash App:
1. Train and save the model
2. Run the app.py file
  
![Gif](anim.gif)
